const failure = document.querySelector(".container-details-failure");

export function showDetailsFailure() {
	console.log("abre o details");
	if (failure) {
		failure.classList.add("show-details-failure");
	}
	else {
		console.log("Container Details Failure não foi encontrado.");
	}
}