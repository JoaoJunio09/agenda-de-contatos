import { showDetailsFailure } from "../utils/detailsFailure";

const fade = document.querySelector("#fade") as HTMLDivElement;
const btnsOpenModalEditUser = document.querySelectorAll(".btn-open-modal-edit-user") ;
const btnsCloseModalEditUser = document.querySelectorAll(".btn-close-modal-edit-user");
const modalEdit = document.querySelector(".modal-edit-user") as HTMLDivElement;

btnsOpenModalEditUser.forEach(btn => {
	btn.addEventListener('click', () => {
		modalEdit.classList.add("show-modal-edit-user");
		fade.classList.add("show-fade");
	});
});

btnsCloseModalEditUser.forEach(btn => {
	btn.addEventListener('click', () => {
		modalEdit.classList.remove("show-modal-edit-user");
		fade.classList.remove("show-fade");
	});
});

const btnNextPage = document.getElementById("btn-next-page") as HTMLButtonElement;
const btnPreviousPage = document.querySelector("#btn-previous-page") as HTMLButtonElement;
const slider = document.querySelector(".slider") as HTMLDivElement;

let currentStage = 0;

showDetailsFailure();
console.log("Page 1");
btnNextPage.addEventListener('click', () => {
	if (currentStage === 0) {
		currentStage++;
		updateSlider();
	}
	else if (currentStage === 1) {
		currentStage++;
		updateSlider();
		console.log("Page 2");
	}
	else if (currentStage === 2) {
		console.log("Page 3");
	}

	console.log(currentStage);
});

btnPreviousPage.addEventListener('click', () => {
	if (currentStage > 0) {
		currentStage--;
		updateSlider();
	}
});

function updateSlider() {
	let percentage = currentStage * -100;
	slider.style.transform = `translateX(${percentage}%)`;
	console.log(percentage);
}

type Person = {
	id: number | null,
    firstName: string,
    lastName: string,
    birthDate: Date,
    email: string,
    phone: string,
    gender: string,
    address: string,
    complement: string,
    number: number,
    nationality: string,
    cpf: string,
    rg: string,
};

type User = {
	id: number | null,
	email: string,
	password: string,
	person: Person,
};

